package com.theappwelt.rmb.model;


public class Constants {

    public static  final String SHARED_PREFERENCES_KEY_CONTACTS = "Contacts";

    public static  final String APP_NAME = " RMB ";

}
