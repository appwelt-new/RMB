package com.theappwelt.rmb.adapters;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.theappwelt.rmb.R;
import com.theappwelt.rmb.activity.slipManagement.MeetingsCreatedActivity;
import com.theappwelt.rmb.model.MeetingCreatedListModel;

import java.util.ArrayList;

public class MeetingCreatedAdapter  extends RecyclerView.Adapter<MeetingCreatedAdapter.ViewHolder>{
    Context context;
    ArrayList<MeetingCreatedListModel> list ;
    ArrayList<String> data = new ArrayList<>();

    public MeetingCreatedAdapter(Context context, ArrayList<MeetingCreatedListModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MeetingCreatedAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view= layoutInflater.inflate(R.layout.meeting_created_list, parent, false);
       ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MeetingCreatedAdapter.ViewHolder holder, int position) {
        MeetingCreatedListModel m = list.get(position);
        holder.topic.setText(m.getTopic());
        holder.date.setText(m.getDate());
        holder.location.setText(m.getLocation());
        holder.id.setText(m.getMeetingId());
        holder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogEdit(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView topic,date,location,id;
        ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            topic = itemView.findViewById(R.id.meetingCreatedTopic);
            date = itemView.findViewById(R.id.meetingCreatedDate);
            location = itemView.findViewById(R.id.meetingCreatedLocation);
            imageView = itemView.findViewById(R.id.meetingCreatedEdit);
            id = itemView.findViewById(R.id.meetingCreatedId);
        }
    }


    @SuppressLint("SetTextI18n")
    private void DialogEdit(int p) {
        MeetingCreatedListModel r = list.get(p);
        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.edit_create_meeting_list);
        dialog.setCancelable(true);
        Window window = dialog.getWindow();
        assert window != null;
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        EditText topic = dialog.findViewById(R.id.meetingCreatedTopic);
        EditText date = dialog.findViewById(R.id.meetingCreatedDate);
        EditText locatiom= dialog.findViewById(R.id.meetingCreatedLocation);
        String referralId = r.getMeetingId();
        TextView save = dialog.findViewById(R.id.saveReferralReceived);
        TextView cancel = dialog.findViewById(R.id.cancel);
        dialog.show();
        topic.setText(r.getTopic());
        date.setText(r.getDate());
        locatiom.setText(r.getLocation());

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data.add(""+topic.getText().toString());
                data.add(""+date.getText().toString());
                data.add(""+locatiom.getText().toString());
                data.add(""+referralId);
                MeetingsCreatedActivity r = new MeetingsCreatedActivity();
                r.sendMeetingData(data);
                dialog.dismiss();
            }
        });


        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
            }
        });
    }
}
