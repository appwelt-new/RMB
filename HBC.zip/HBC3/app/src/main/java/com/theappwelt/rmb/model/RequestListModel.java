package com.theappwelt.rmb.model;

public class RequestListModel {
    String name;

    public RequestListModel(String name) {
        this.name = name;

    }
    public String getName() {
        return name;
    }
}