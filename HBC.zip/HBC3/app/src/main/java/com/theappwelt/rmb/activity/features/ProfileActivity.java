package com.theappwelt.rmb.activity.features;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.theappwelt.rmb.R;
import com.theappwelt.rmb.utilities.ServiceHandler;
import com.theappwelt.rmb.utilities.Utils;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;


import okhttp3.FormBody;
import okhttp3.RequestBody;

public class ProfileActivity extends AppCompatActivity {
    String userid;
    TextView memberId,memberName,memberFullName,memberMobile,memberEmail,branch,location,businessName,businessCategory,businessSubCategory;
    ImageView profileImg;
    String imageUrl="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        getSupportActionBar().setTitle(" My Profile");
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        userid = sh.getString("memberId", "");


        memberId = findViewById(R.id.proMemberId);
        memberName = findViewById(R.id.pro_name);
        memberFullName = findViewById(R.id.proFullName);
        memberMobile = findViewById(R.id.proMobile);
        memberEmail = findViewById(R.id.proEmail);
        profileImg = findViewById(R.id.profileImageView);
        branch = findViewById(R.id.proBranch);
        location = findViewById(R.id.proLocation);
        businessName = findViewById(R.id.proBusinessName);
        businessCategory = findViewById(R.id.proBusinessCategory);
        businessSubCategory = findViewById(R.id.proBusinessSubCategory);

        new getProfileData().execute();

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(i);
        finish();
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent( getApplicationContext(),MainActivity.class);
                startActivity(intent);
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }



    public  class getProfileData extends AsyncTask<String, Void, String> {

        private String jsonStr, responseSuccess, responseMsg;
        private JSONObject jsonData;

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... args) {
            // TODO Auto-generated method stub
            try {
                ServiceHandler shh = new ServiceHandler(ProfileActivity.this);

                RequestBody values = new FormBody.Builder()
                        .add("memberId",userid)
                        .build();
                jsonStr = shh.makeServiceCall("http://3.6.102.75/rmbapiv1/member/getinfo", ServiceHandler.POST, values);
                Log.d("meeting: ", "> " + jsonStr);

            } catch (final Exception e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Utils.showDialog(ProfileActivity.this, e.toString(), false, false);
                    }
                });
                // workerThread();
                Log.e("ServiceHandler", e.toString());
            }
            return jsonStr;
        }

        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String jsonStr) {
            // TODO Auto-generated method stub
            super.onPostExecute(jsonStr);
            try {

                if (jsonStr != null) {
                    jsonData = new JSONObject(jsonStr);
                    Log.d("ReferralReceived1", "" + jsonData.toString());
                    responseSuccess = String.valueOf(jsonData.getInt("message_code"));
                    Log.d("profile", "" + responseSuccess);
                    if (responseSuccess.equals("1000")) {
                        JSONObject userArray = jsonData.getJSONObject("message_text");
                        Log.d("profile", "" + userArray.toString());
                            JSONObject userDetail = userArray.getJSONObject("memberinfo");
                        Log.d("profile", "" + userDetail.toString());

                            memberFullName.setText("Member Name : "+userDetail.getString("member_first_name")+ " "+userDetail.getString("member_last_name"));
                            branch.setText("Branch : " +userDetail.getString("branch_name"));
                            memberName.setText(userDetail.getString("member_first_name")+ " "+userDetail.getString("member_last_name"));
                            memberId.setText("Member Id : "+userDetail.getString("hbc_member_id"));
                            memberMobile.setText(memberMobile.getText().toString()+""+userDetail.getString("member_mobile"));
                            memberEmail.setText("Email : "+userDetail.getString("member_email"));
                          //  location.setText("Address : "+ userDetail.getString("member_address"));
                            imageUrl = "Address : "+ userDetail.getString("member_profile_photo");
                        Picasso.get().load(imageUrl).into(profileImg);
                        JSONObject businessDetails = userArray.getJSONObject("businessinfo");

                        businessName.setText("Business Name : "+businessDetails.getString("business_Name"));
                        businessCategory.setText("Business Category : "+businessDetails.getString("Category_Name"));
                        businessSubCategory.setText("SubCategory : "+businessDetails.getString("Subcategory_Name"));

                        }

                    } else {
                        responseMsg = jsonData.getString("message_text");
                        Utils.showDialog(ProfileActivity.this, responseMsg, false, false);
                    }
                } catch (JSONException jsonException) {
                jsonException.printStackTrace();

            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }

}