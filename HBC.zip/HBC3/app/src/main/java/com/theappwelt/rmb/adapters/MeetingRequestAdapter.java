package com.theappwelt.rmb.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.theappwelt.rmb.R;
import com.theappwelt.rmb.activity.slipManagement.MeetingRequestActivity;
import com.theappwelt.rmb.model.MeetingRequestedListModel;

import java.util.ArrayList;

public class MeetingRequestAdapter extends RecyclerView.Adapter<MeetingRequestAdapter.ViewHolder>{
    Context context;
    ArrayList<MeetingRequestedListModel> data;

    public MeetingRequestAdapter(Context context, ArrayList<MeetingRequestedListModel> data) {
        this.context = context;
        this.data = data;
    }
    
    @NonNull
    @Override
    public MeetingRequestAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view= layoutInflater.inflate(R.layout.meeting_request_list, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MeetingRequestAdapter.ViewHolder holder, int position) {

        MeetingRequestedListModel m = data.get(position);
        holder.name.setText(m.getName());
        holder.topic.setText(m.getTopic());
        holder.date.setText(m.getDate());
        holder.location.setText(m.getLocation());

        holder.accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, " Accepted... ", Toast.LENGTH_SHORT).show();
                holder.accept.setVisibility(View.GONE);
                holder.reject.setVisibility(View.GONE);
                MeetingRequestActivity r = new MeetingRequestActivity();
                r.getData(data.get(position).getMeetingId(),"2");

            }
        });

        holder.reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name,topic,date,location,accept,reject;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.meetingRequestName);
            topic = itemView.findViewById(R.id.meetingRequestTopic);
            date = itemView.findViewById(R.id.meetingRequestDate);
            location = itemView.findViewById(R.id.meetingRequestLocation);
            accept = itemView.findViewById(R.id.meetingRequestAccept);
            reject = itemView.findViewById(R.id.meetingRequestReject);
        }
    }
    public void dialog(int p){
        AlertDialog.Builder builder=new AlertDialog.Builder(context);
        // Set title
        builder.setTitle("Decline !!");
        // set message
        builder.setMessage(data.get(p).getName() +" meeting request ");
        // Set non cancelable
        builder.setCancelable(false);

        // On update
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
              data.remove(p);
                notifyDataSetChanged();
                dialogInterface.dismiss();
                MeetingRequestActivity r = new MeetingRequestActivity();
                r.getData(data.get(p).getMeetingId(),"3");

            }
        });

        // on cancel
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // cancel alert dialog
                dialogInterface.cancel();
            }
        });

        // show alert dialog
        builder.show();
    }
    }

