package com.theappwelt.rmb.model;

public class MeetingCreatedListModel {

    String topic,date,location,meetingId;

    public MeetingCreatedListModel(String topic, String date, String location,String meetingId) {
        this.topic = topic;
        this.date = date;
        this.location = location;
        this.meetingId = meetingId;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


    public String getMeetingId() {
        return meetingId;
    }

    public void setMeetingId(String meetingId) {
        this.meetingId = meetingId;
    }
}
