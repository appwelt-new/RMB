package com.theappwelt.rmb.activity.slipManagement;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.theappwelt.rmb.R;
import com.theappwelt.rmb.adapters.ReferralGivenAdapter;
import com.theappwelt.rmb.model.ReferralsGivenListModel;
import com.theappwelt.rmb.utilities.ServiceHandler;
import com.theappwelt.rmb.utilities.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.FormBody;
import okhttp3.RequestBody;

public class ReferralsGivenActivity extends AppCompatActivity {
    String userid = "";
    public String referralId = "";
  ArrayList<String> data = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setTitle("Referrals Given");
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_referrals_given);
        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        userid = sh.getString("memberId", "");
        new getReferralGivenList().execute();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onBackPressed();
        finish();
        return super.onOptionsItemSelected(item);
    }

    public void sendData(ArrayList<String> data2) {
        data=data2;
        new updateReferral().execute();

    }


    public class getReferralGivenList extends AsyncTask<String, Void, String> {
        ArrayList<ReferralsGivenListModel> data = new ArrayList<>();

        RecyclerView rvReferralsGiven;
        ReferralGivenAdapter referralGivenAdapter;
        private String jsonStr, responseSuccess, responseMsg;
        private JSONObject jsonData;

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... args) {
            // TODO Auto-generated method stub
            try {
                ServiceHandler shh = new ServiceHandler(ReferralsGivenActivity.this);
                RequestBody values = new FormBody.Builder()
                        .add("member_id", userid)
                        .build();
                jsonStr = shh.makeServiceCall("http://3.6.102.75/rmbapiv1/slip/getReferralSlip", ServiceHandler.POST, values);
                Log.d("meeting: ", "> " + jsonStr);
            } catch (final Exception e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Utils.showDialog(ReferralsGivenActivity.this, e.toString(), false, false);
                    }
                });
                Log.e("ServiceHandler", e.toString());
            }
            return jsonStr;
        }

        @Override
        protected void onPostExecute(String jsonStr) {
            // TODO Auto-generated method stub
            super.onPostExecute(jsonStr);
            try {
                if (jsonStr != null) {
                    jsonData = new JSONObject(jsonStr);
                    Log.d("ReferralReceived1", "" + jsonData.toString());
                    responseSuccess = String.valueOf(jsonData.getInt("message_code"));
                    Log.d("Referral2", "" + responseSuccess);
                    if (responseSuccess.equals("1000")) {
                        JSONArray userArray = jsonData.getJSONArray("message_text");
                        for (int i = 0; i < userArray.length(); i++) {
                            JSONObject userDetail = userArray.getJSONObject(i);
                            referralId = userDetail.getString("referral_id");
                            Log.d("referral_id",referralId.toString());
                            String memberFirstName = userDetail.getString("member_first_name");
                            String memberLastName = userDetail.getString("member_last_name");
                            String referralName = userDetail.getString("referral_name");
                            String referralStatus = userDetail.getString("referral_status_name");
                            String email = userDetail.getString("referral_email");
                            String phone = userDetail.getString("referral_phone");
                            String address = userDetail.getString("referral_address");
                            String comments = userDetail.getString("referral_comment");
                            ReferralsGivenListModel r = new ReferralsGivenListModel(referralId,memberFirstName + " " + memberLastName, referralName, referralStatus, email, phone, address, comments);
                            data.add(r);

                        }
                    } else {
                        responseMsg = jsonData.getString("message_text");
                        Utils.showDialog(ReferralsGivenActivity.this, responseMsg, false, false);
                    }
                } else {
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            rvReferralsGiven = (RecyclerView) findViewById(R.id.rvReferralsGiven);
            rvReferralsGiven.setLayoutManager(new LinearLayoutManager(ReferralsGivenActivity.this));
            referralGivenAdapter = new ReferralGivenAdapter(ReferralsGivenActivity.this, data);
            rvReferralsGiven.setAdapter(referralGivenAdapter);
        }
    }



    public class updateReferral extends AsyncTask<String, Void, String> {
        private String jsonStr, responseSuccess, responseMsg;
        private JSONObject jsonData;

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... args) {
            // TODO Auto-generated method stub
            try {
                ServiceHandler shh = new ServiceHandler(ReferralsGivenActivity.this);
                RequestBody values = new FormBody.Builder()
                        .add("referralId", data.get(5))
                        .add("rName", data.get(0))
                        .add("mobileNo", data.get(1))
                        .add("email", data.get(2))
                        .add("address", data.get(3))
                        .add("comments", data.get(4))
                        .build();
                jsonStr = shh.makeServiceCall("http://3.6.102.75/rmbapiv1/slip/updateReferralDetail", ServiceHandler.POST, values);
Log.d("referralId",data.get(5));

            } catch (final Exception e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Utils.showDialog(ReferralsGivenActivity.this, e.toString(), false, false);
                    }
                });
                // workerThread();
                Log.e("ServiceHandler", e.toString());
            }
            return jsonStr;
        }

        @Override
        protected void onPostExecute(String jsonStr) {
            // TODO Auto-generated method s]tub
            super.onPostExecute(jsonStr);
            try {
                if (jsonStr != null) {
                    jsonData = new JSONObject(jsonStr);
                    responseSuccess = String.valueOf(jsonData.getInt("message_code"));
                    Log.d("isSuccess", "" + responseSuccess);
                    if (responseSuccess.equals("1000")) {
                    } else {
                        responseMsg = jsonData.getString("message_text");
                        Utils.showDialog(ReferralsGivenActivity.this, responseMsg, false, false);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
