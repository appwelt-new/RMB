package com.theappwelt.rmb.activity.slipManagement;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.theappwelt.rmb.R;
import com.theappwelt.rmb.activity.features.MainActivity;
import com.theappwelt.rmb.adapters.MeetingCreatedAdapter;
import com.theappwelt.rmb.model.MeetingCreatedListModel;
import com.theappwelt.rmb.utilities.ServiceHandler;
import com.theappwelt.rmb.utilities.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.FormBody;
import okhttp3.RequestBody;

public class MeetingsCreatedActivity extends AppCompatActivity {
    ArrayList<String> data = new ArrayList<>();
    SharedPreferences sh;
    String userId = "";
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meetings_created);
        getSupportActionBar().setTitle("Meetings Created");
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        userId = sh.getString("memberId", "");

        new getCreatedMeetingList().execute();


    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public void sendMeetingData(ArrayList<String> data2) {
       data=data2;

        for (int i = 0; i <data.size() ; i++) {
            Log.d("CreateIsSuccess", "" + data.get(i) + " " +i);
        }

       //Toast.makeText(MeetingsCreatedActivity.this, " API error!!! ", Toast.LENGTH_SHORT).show();
        new updateMeeting().execute();
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onBackPressed();
        finish();
        return super.onOptionsItemSelected(item);
    }

    @SuppressLint("SetTextI18n")
    public  class getCreatedMeetingList extends AsyncTask<String, Void, String> {
        ArrayList<MeetingCreatedListModel> data = new ArrayList<>();

        RecyclerView rvMeetingCtreated;
        MeetingCreatedAdapter meetingCreatedAdapter;
        private String jsonStr, responseSuccess, responseMsg;
        private JSONObject jsonData;

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... args) {
            // TODO Auto-generated method stub
            try {
                ServiceHandler shh = new ServiceHandler(MeetingsCreatedActivity.this);

                RequestBody values = new FormBody.Builder()
                        .add("member_id",userId)
                        .build();
                jsonStr = shh.makeServiceCall("http://3.6.102.75/rmbapiv1/slip/getOwnMeetings", ServiceHandler.POST, values);
                Log.d("visitor: ", "> " + jsonStr);

            } catch (final Exception e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Utils.showDialog(MeetingsCreatedActivity.this, e.toString(), false, false);
                    }
                });
                // workerThread();
                Log.e("ServiceHandler", e.toString());
            }
            return jsonStr;
        }

        @Override
        protected void onPostExecute(String jsonStr) {
            // TODO Auto-generated method stub
            super.onPostExecute(jsonStr);
            try {
                if (jsonStr != null) {
                    jsonData = new JSONObject(jsonStr);
                    responseSuccess = String.valueOf(jsonData.getInt("message_code"));
                    Log.d("isSuccess", "" + responseSuccess);
                    if (responseSuccess.equals("1000")) {
                        JSONArray userArray = jsonData.getJSONArray("message_text");
                        Log.d("isSuccess2 visitorucc",userArray.toString());
                        for (int i = 0; i < userArray.length(); i++) {
                            JSONObject userDetail = userArray.getJSONObject(i);
                          String  topic  = userDetail.getString("topic_of_discussion");
                           String  date = userDetail.getString("expected_date_and_time");
                           String location = userDetail.getString("expected_location");
                           String meeting_id = userDetail.getString("meeting_id");
                           MeetingCreatedListModel m = new MeetingCreatedListModel(topic,date,location,meeting_id);
                           data.add(m);

                        }

                    } else {
                        responseMsg = jsonData.getString("message_text");
                        Utils.showDialog(MeetingsCreatedActivity.this, responseMsg, false, false);
                    }
                } else {
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            rvMeetingCtreated = (RecyclerView) findViewById(R.id.rvMeetingsCreated);
            rvMeetingCtreated.setLayoutManager(new LinearLayoutManager(MeetingsCreatedActivity.this));
            meetingCreatedAdapter = new MeetingCreatedAdapter (MeetingsCreatedActivity.this,data);
            rvMeetingCtreated.setAdapter(meetingCreatedAdapter);

        }
    }
    public class updateMeeting extends AsyncTask<String, Void, String> {
        private String jsonStr, responseSuccess, responseMsg;
        private JSONObject jsonData;

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... args) {
            // TODO Auto-generated method stub
            try {

                ServiceHandler shh = new ServiceHandler(MeetingsCreatedActivity.this);
                RequestBody values = new FormBody.Builder()

                        .add("topic", data.get(0))
                        .add("eStartTime", data.get(1))
                        .add("location", data.get(2))
                        .add("meetingMember_id",data.get(3))
                        .add("user_id", userId)
                        .build();
                Log.d("CreateIsSuccess22", "" + "5");
                jsonStr = shh.makeServiceCall("http://3.6.102.75/rmbapiv1/slip/updateMemberMeeting", ServiceHandler.POST, values);


            } catch (final Exception e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Utils.showDialog(MeetingsCreatedActivity.this, e.toString(), false, false);
                    }
                });
                // workerThread();
                Log.e("ServiceHandler", e.toString());
            }
            return jsonStr;
        }

        @Override
        protected void onPostExecute(String jsonStr) {
            // TODO Auto-generated method stub
            super.onPostExecute(jsonStr);
            try {
                if (jsonStr != null) {
                    Log.d("CreateIsSuccess22", "" + jsonStr.toString());
                    jsonData = new JSONObject(jsonStr);
                    responseSuccess = String.valueOf(jsonData.getInt("message_code"));

                    if (responseSuccess.equals("1000") || responseSuccess.toString() == "1000" ) {
                        Log.d("CreateIsSuccess22", "" + responseSuccess);
                        Intent i = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(i);
                        finish();
                    } else {
                        responseMsg = jsonData.getString("message_text");
                        Utils.showDialog(MeetingsCreatedActivity.this, responseMsg, false, false);
                    }
                }
            } catch (Exception e) {
                Log.d("CreateIsSuccess", "" + e);
                e.printStackTrace();
            }
        }
    }
}